using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Switch : MonoBehaviour
{
    public void Bswitch(){
        // Start is called before the first frame update
        SceneManager.LoadScene("Calender");
    }
}
